Gen2 Softworks website
Open index.html in any browser. No backend or build step needed.
Fonts load from Google Fonts when online.
For the video to play inside the page, host the site on a domain (opening the file directly from a folder opens the YouTube link instead).
